$(document).ready(function(){  
			  show_hex();
			});

			function show_hex(){
			  $(".hex_ani").hex({show: true, direction: "left", background: "#0769ad", duration: 5, delay: 0, callback: function(){setTimeout("hide_hex()",5000);}});
			  
			}

			function hide_hex(){
			  $(".hex_ani").hex({show: false, direction: "left", background: "#0769ad", duration: 5, delay: 0, callback: function(){setTimeout("show_hex()",5000);}});
 }








//hexmin.js
!function(a){a.fn.hex=function(b){var c=a.extend({show:!0,direction:"right",background:"#eee",duration:10,delay:0,callback:function(){}},b),d=String.fromCharCode(65+Math.floor(26*Math.random())),e=d+Date.now();a(".hexagon",this).length>0?e=a(".hexagon",this).attr("class").split(/\s+/)[0].replace("hex",""):(c.show?a("html head").append("<style type='text/css'>.hex"+e+":before {content: ''; width: 0; height: 0; border-bottom: 12px solid "+c.background+"; border-left: 22px solid transparent; border-right: 22px solid transparent; position: absolute; top: -12px;} .hex"+e+" {z-index: inherit; margin-top: 12px; width: 44px; height: 25px; background-color: "+c.background+"; position: absolute; top: 300px; margin-left: 1px;} .hex"+e+":after { content: ''; width: 0; position: absolute; bottom: -12px; border-top: 12px solid "+c.background+"; border-left: 22px solid transparent; border-right: 22px solid transparent;}</style>"):a("html head").append("<style type='text/css'>.hex"+e+":before {content: ''; width: 0; height: 0; border-bottom: 12px solid "+c.background+"; border-left: 22px solid transparent; border-right: 22px solid transparent; position: absolute; top: -12px;} .hex"+e+" {z-index: inherit; display: none; opacity: 0; margin-top: 12px; width: 44px; height: 25px; background-color: "+c.background+"; position: absolute; top: 300px; margin-left: 1px;} .hex"+e+":after { content: ''; width: 0; position: absolute; bottom: -12px; border-top: 12px solid "+c.background+"; border-left: 22px solid transparent; border-right: 22px solid transparent;}</style>"),a(this).each(function(){for(var c=a(this).width(),d=a(this).height(),f=Math.ceil(c/40)*Math.ceil(d/25),g=-30,h=-30,i=0,j=0,k=0;f>k;k++)j>Math.ceil(c/40)&&(i++,j=0),0==i%2?a(this).append("<div class='hex"+e+" hexagon' style='margin-left: 23px; top:"+(h+36*i)+"px; left:"+(g+44*j)+"px;'></div>"):a(this).append("<div class='hex"+e+" hexagon' style='top:"+(h+36*i)+"px; left:"+(g+44*j)+"px;'></div>"),j++})),a(this).each(function(){a(".hex"+e,this).each(function(){if("right"==c.direction)var b=parseInt(a(this).css("left"));else if("left"==c.direction)var b=parseInt(a(this).parent().width())-parseInt(a(this).css("left"));else if("up"==c.direction)var b=a(this).parent().height()-a(this).offset().top;else if("down"==c.direction)var b=a(this).offset().top;else if("random"==c.direction)var b=200*Math.random();else if("center"==c.direction){var d=parseInt(a(this).parent().width())/2,f=parseInt(a(this).css("left")),g=parseInt(a(this).parent().height())/2,h=parseInt(a(this).css("top"));if(f>d)if(h>g)var b=parseInt(f)-parseInt(d)+h;else var b=parseInt(f)-parseInt(d)-h;else if(h>g)var b=parseInt(d)-parseInt(f)-h;else var b=parseInt(d)-parseInt(f)-h}c.duration<=0&&(c.duration=1),c.delay<0&&(c.delay=1);var i=c.delay+b*c.duration*Math.random();c.show?a(this).delay(i).animate({opacity:0},600,function(){a(this).css("display","none"),a(this).remove(),a(".hex"+e).length>0||c.callback.call(this)}):(a(this).css("display","block"),a(this).delay(i).animate({opacity:1},600,function(){var b=0;a(".hex"+e).each(function(){1==a(this).css("opacity")&&b++}),b>=a(".hex"+e).length&&c.callback.call(this)}))})})}}(jQuery);