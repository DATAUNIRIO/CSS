# <mark> highlight on scroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/martingarnett01/pen/jOWMXmQ](https://codepen.io/martingarnett01/pen/jOWMXmQ).

