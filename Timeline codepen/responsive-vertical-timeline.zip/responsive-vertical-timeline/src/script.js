/*
9/22/2014 - Update 1: Added Author Name and changed some html and css. :) Enjoy.
*/