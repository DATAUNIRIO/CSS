// Inspired by some sticker icons that
// I got from istockphoto awhile ago:
// http://www.istockphoto.com/stock-illustration-8968204-education-sticker-icons.php?st=0a31d2b

// Icons from Heydings Icon Font
// http://www.heydonworks.com/article/a-free-icon-web-font
// I converted to data URIs because Firefox
// wasn't playing nice with the whole cross-domain thing