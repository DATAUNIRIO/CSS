function _(e, all=false) {
    let divs = document.querySelectorAll(e);
    if (all || (divs.length > 1)) { return divs; }
    return divs[0];
}

Object.defineProperty(Array.prototype, 'shuffle', {
    value: function() {
        for (let i = this.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this[i], this[j]] = [this[j], this[i]];
        }
        return this;
    }
});

let posArr = [0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100];


let xArr, yArr; 
const sclMin = 0;
const sclMax = 100;
const scrSize = 20;
let sclPos = 0;

let objs = [
    {
        objDiv: _('.txt01'),
        pos: 0,
        parameters: {
            top: `(50 + ((obj.pos - sclPos) * 5)) + '%'`,
        },
    },
    {
        objDiv: _('.txt02'),
        pos: 20,
        parameters: {
            top: `(50 + ((obj.pos - sclPos) * 5)) + '%'`,
            left: `(50 + ((obj.pos - sclPos) * 5)) + '%'`,
        },
    },
    {
        objDiv: _('.txt03'),
        pos: 40,
        parameters: {
            top: `(50 + ((obj.pos - sclPos) * 5)) + '%'`,
            left: `(50 + ((sclPos - obj.pos) * 5)) + '%'`,
        },
    },
    {
        objDiv: _('.txt04'),
        pos: 60,
        parameters: {
            top: `(50 + ((sclPos - obj.pos) * 5)) + '%'`,
        },
    },
    {
        objDiv: _('.txt05'),
        pos: 80,
        parameters: {
            opacity: '(1 - Math.abs((obj.pos - sclPos) / 10))',
            transform: `'translate(-50%, -50%) scale(' + (1 + Math.abs((obj.pos - sclPos) / 40)) + ')'`,
            filter: `'blur(' + Math.abs(obj.pos - sclPos) + 'px)'`
        },
    },
    {
        objDiv: _('.txt06'),
        pos: 100,
        parameters: {
            top: `(50 + ((sclPos - obj.pos) * 5)) + '%'`,
            left: `(50 + ((sclPos - obj.pos) * 5)) + '%'`,
        },
    },
]

xArr = posArr.shuffle().map((x) => x);
yArr = posArr.shuffle().map((y) => y);
for (let index = 0; index < posArr.length-1; index++) {

    let objDiv = document.createElement('div');
    objDiv.classList = 'hex ' + index;

    const obj = {
        objDiv: objDiv,
        pos: 0,
        parameters: {
            top: `(${yArr[index]} + ((obj.pos - sclPos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
            left: `${xArr[index]} + '%'`,
        },
    }
    
    _('.container').appendChild(objDiv);
    objs.push(obj)
}

xArr = posArr.shuffle().map((x) => x);
yArr = posArr.shuffle().map((y) => y);
for (let index = 0; index < posArr.length-1; index++) {

    let objDiv = document.createElement('div');
    objDiv.classList = 'hex ' + index;

    const obj = {
        objDiv: objDiv,
        pos: 20,
        parameters: {
            top: `(${yArr[index]} + ((obj.pos - sclPos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
            left: `(${xArr[index]} + ((obj.pos - sclPos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
        },
    }
    
    _('.container').appendChild(objDiv);
    objs.push(obj)
}

xArr = posArr.shuffle().map((x) => x);
yArr = posArr.shuffle().map((y) => y);
for (let index = 0; index < posArr.length-1; index++) {

    let objDiv = document.createElement('div');
    objDiv.classList = 'hex ' + index;

    const obj = {
        objDiv: objDiv,
        pos: 40,
        parameters: {
            top: `(${yArr[index]} + ((obj.pos - sclPos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
            left: `(${xArr[index]} + ((sclPos - obj.pos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
        },
    }
    
    _('.container').appendChild(objDiv);
    objs.push(obj)
}

xArr = posArr.shuffle().map((x) => x);
yArr = posArr.shuffle().map((y) => y);
for (let index = 0; index < posArr.length-1; index++) {

    let objDiv = document.createElement('div');
    objDiv.classList = 'hex ' + index;

    const obj = {
        objDiv: objDiv,
        pos: 60,
        parameters: {
            top: `(${yArr[index]} + ((sclPos - obj.pos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
            left: `${xArr[index]} + '%'`,
        },
    }
    
    _('.container').appendChild(objDiv);
    objs.push(obj)
}

xArr = posArr.shuffle().map((x) => x);
yArr = posArr.shuffle().map((y) => y);
for (let index = 0; index < posArr.length-1; index++) {

    let objDiv = document.createElement('div');
    objDiv.classList = 'hex ' + index;

    const obj = {
        objDiv: objDiv,
        pos: 80,
        parameters: {
            top: `(${yArr[index]} + ((sclPos - obj.pos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
            left: `(${xArr[index]} + ((obj.pos - sclPos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
        },
    }
    
    _('.container').appendChild(objDiv);
    objs.push(obj)
}

xArr = posArr.shuffle().map((x) => x);
yArr = posArr.shuffle().map((y) => y);
for (let index = 0; index < posArr.length-1; index++) {

    let objDiv = document.createElement('div');
    objDiv.classList = 'hex ' + index;

    const obj = {
        objDiv: objDiv,
        pos: 100,
        parameters: {
            top: `(${yArr[index]} + ((sclPos - obj.pos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
            left: `(${xArr[index]} + ((sclPos - obj.pos) * ${5 + Math.round(Math.random() * 5)})) + '%'`,
        },
    }
    
    _('.container').appendChild(objDiv);
    objs.push(obj)
}

window.onload = () => {

    for (let i = 0; i < objs.length; i++) {

        let obj = objs[i];
        
        if (obj.objDiv.classList.contains('hex')) {
            obj.objDiv.style.transform = `translate(-50%, -50%) scale(${0.25 + Math.random() * 0.75})`;
            obj.objDiv.style.filter = `drop-shadow(5px 10px 20px #0007) brightness(${Math.round(120 - Math.random() * 100)}%) hue-rotate(var(--hr))`;
            obj.objDiv.style.zIndex = Math.round(Math.random() * 10);
        }

        if (obj.parameters) {
            Object.keys(obj.parameters).forEach(parameterKey => {
                let parameter = obj.parameters[parameterKey]
                obj.objDiv.style[parameterKey] = parameter.start + parameter.units;
            });
        }

    }
    setTimeout(() => {
        document.documentElement.style.setProperty('--tr', "0.5s");
    }, 1);

}

window.onscroll = () => {
    switch (window.pageYOffset || document.documentElement.scrollTop) {
        case 1:
            return false;
            break;
        case 0:
            sclPos = Math.max(sclMin, (sclPos-2));
            break;
        default:
            sclPos = Math.min(sclMax, (sclPos+2));
            break;
    }
    window.scrollTo(0, 1);
    drawView()
}

drawView(true);
function drawView(setAll=false) {
    console.log('drawView', sclPos)

    for (let i = 0; i < objs.length; i++) {

        let obj = objs[i];

        if ((Math.abs(sclPos - obj.pos) > 20) && !setAll) { continue; }

        Object.keys(obj.parameters).forEach(parameter => {
            obj.objDiv.style[parameter] = eval(obj.parameters[parameter]);
        });
        document.documentElement.style.setProperty('--hr', ((sclPos+10) / 200) + "turn");
    }
}