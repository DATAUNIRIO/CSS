(function() {
var stage = document.querySelector('#stage');
var parallax = new Parallax(stage);
}());